package udla.alfredo.chiguano.exa.prog2;

import java.util.ArrayList;
import java.util.List;

public class Venta {
    private String id;
    private String fecha;
    private Empleado empleado;
    private List<Producto> productosVendidos;
    private double total;

    public Venta(String id, String fecha, Empleado empleado) {
        this.id = id;
        this.fecha = fecha;
        this.empleado = empleado;
        this.productosVendidos = new ArrayList<>();
        this.total = 0;
    }

    public void agregarProducto(Producto producto, int cantidad) {
        if (producto.getCantidad() >= cantidad) {
            producto.reducirCantidad(cantidad);
            productosVendidos.add(producto);
            total += producto.getPrecio() * cantidad;
        } else {
            System.out.println("Stock insuficiente para la venta.");
        }
    }

    public double getTotal() {
        return total;
    }

    public void mostrarProductos() {
        for (Producto producto : productosVendidos) {
            System.out.println(producto);
        }
    }
}
