package udla.alfredo.chiguano.exa.prog2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Inventario y empleados predefinidos
        Ropa ropa = new Ropa("R001", "Camisa", 20.0, 10, "M");
        Accesorio accesorio = new Accesorio("A001", "Pulsera", 15.0, 5, "Oro");
        Calzado calzado = new Calzado("C001", "Zapato", 50.0, 3, 42);
        Vendedor vendedor = new Vendedor("V001", "Carlos", 3000.0, 5.0);

        Venta venta = new Venta("VTA001", "2024-12-02", vendedor);

        System.out.println("Sistema de gestión de ventas - Opciones:");
        int opcion;
        do {
            System.out.println("1. Agregar producto\n2. Mostrar productos vendidos\n3. Mostrar total\n4. Salir");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.println("Seleccione un producto: 1. Ropa 2. Accesorio 3. Calzado");
                    int productoOpcion = sc.nextInt();
                    sc.nextLine();
                    Producto seleccionado;
                    if (productoOpcion == 1) seleccionado = ropa;
                    else if (productoOpcion == 2) seleccionado = accesorio;
                    else seleccionado = calzado;

                    System.out.println("Ingrese cantidad:");
                    int cantidad = sc.nextInt();
                    venta.agregarProducto(seleccionado, cantidad);
                }
                case 2 -> venta.mostrarProductos();
                case 3 -> System.out.println("Total de la venta: " + venta.getTotal());
                case 4 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 4);
    }
}